{-# LANGUAGE OverloadedStrings #-}
module Utils where

import Text.Blaze.Html
import qualified Text.Blaze.Html5 as H
import qualified Text.Blaze.Html5.Attributes as A

data Lang = Javascript | Elm
