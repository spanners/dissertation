main = [markdown|
<style type="text/css">p { text-align:justify; }</style>

# Try Elm

This is an online editor for writing and compiling
<a href="/" target="_top">Elm</a> code. If you
are unsure how to get started, take a look at the
<a href="/Examples.elm" target="_top">examples</a>
or <a href="/Learn.elm" target="_top">learning resources</a>.
|]
