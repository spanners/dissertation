var firebaseData = new Firebase(
		'https://sweltering-fire-9141.firebaseio.com/dissertation');
var embedMe = Elm.fullscreen(Elm.EmbedMe, {});
